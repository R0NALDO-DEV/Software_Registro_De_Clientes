import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import re
import json
import threading

class RegistroClienteApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Registro de Cliente")
        
        # Alteração para o caminho do ícone
        caminho_do_script = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        caminho_do_icone = os.path.join(caminho_do_script, "icon.ico")
        self.root.iconbitmap(caminho_do_icone)
        
        self.clientes = []
        self.arquivo_inserido = False
        self.arquivo_salvo = False
        self.arquivo_atual = None
        self.running = True  
        self.thread_autosalvamento = None  
        self.janela_consulta_atual = None  

        self.style = ttk.Style()
        self.style.theme_use('clam')

        self.criar_menu()
        self.inicializar_interface()

        self.root.protocol("WM_DELETE_WINDOW", self.fechar_aplicativo)

        self.salvar_automaticamente()  

    def criar_menu(self):
        menubar = tk.Menu(self.root)
        self.file_menu = tk.Menu(menubar, tearoff=0)
        self.file_menu.add_command(label="Carregar", command=self.carregar_arquivo)
        self.file_menu.add_command(label="Salvar", command=self.salvar_arquivo, state="disabled")
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Sair", command=self.fechar_aplicativo)
        menubar.add_cascade(label="Arquivo", menu=self.file_menu)
        self.root.config(menu=menubar)

    def carregar_arquivo(self):
        try:
            filename = filedialog.askopenfilename(filetypes=[("JSON Files", "*.json")])
            if filename:
                with open(filename, "r") as f:
                    self.clientes = json.load(f)
                messagebox.showinfo("Carregar", "Dados carregados com sucesso.")
                self.arquivo_inserido = True
                self.file_menu.entryconfig("Carregar", state="disabled")
                self.file_menu.entryconfig("Salvar", state="normal")
                self.btn_registrar.config(state="normal")
                self.btn_consultar.config(state="normal")
                self.arquivo_atual = filename
        except Exception as e:
            messagebox.showerror("Erro ao Carregar", f"Ocorreu um erro ao carregar o arquivo: {str(e)}")

    def salvar_arquivo(self):
        try:
            if not self.arquivo_atual:
                filename = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON Files", "*.json")])
                if not filename:
                    return
                self.arquivo_atual = filename
            with open(self.arquivo_atual, "w") as f:
                json.dump(self.clientes, f)
            messagebox.showinfo("Salvar", "Dados salvos com sucesso.")
            self.arquivo_salvo = True
        except Exception as e:
            messagebox.showerror("Erro ao Salvar", f"Ocorreu um erro ao salvar o arquivo: {str(e)}")

    def inicializar_interface(self):
        self.main_frame = ttk.Frame(self.root, padding=(20, 10))
        self.main_frame.grid(row=0, column=0, sticky="ew")

        self.label_nome = ttk.Label(self.main_frame, text="Nome Completo:")
        self.label_nome.grid(row=0, column=0, sticky="e")
        self.var_nome = tk.StringVar()
        self.entry_nome = ttk.Entry(self.main_frame, width=40, textvariable=self.var_nome)
        self.entry_nome.grid(row=0, column=1)
        self.var_nome.trace("w", lambda *args: self.limitar_entrada(self.var_nome))

        self.label_email = ttk.Label(self.main_frame, text="E-mail:")
        self.label_email.grid(row=1, column=0, sticky="e")
        self.var_email = tk.StringVar()
        self.entry_email = ttk.Entry(self.main_frame, width=40, textvariable=self.var_email)
        self.entry_email.grid(row=1, column=1)
        self.var_email.trace("w", lambda *args: self.limitar_entrada(self.var_email))

        self.label_telefone = ttk.Label(self.main_frame, text="Telefone:")
        self.label_telefone.grid(row=2, column=0, sticky="e")
        self.var_telefone = tk.StringVar()
        self.entry_telefone = ttk.Entry(self.main_frame, width=40, textvariable=self.var_telefone)
        self.entry_telefone.grid(row=2, column=1)
        self.var_telefone.trace("w", lambda *args: self.limitar_entrada(self.var_telefone))

        self.label_cpf = ttk.Label(self.main_frame, text="CPF:")
        self.label_cpf.grid(row=3, column=0, sticky="e")
        self.var_cpf = tk.StringVar()
        self.entry_cpf = ttk.Entry(self.main_frame, width=40, textvariable=self.var_cpf)
        self.entry_cpf.grid(row=3, column=1)
        self.var_cpf.trace("w", lambda *args: self.limitar_entrada(self.var_cpf))

        self.btn_registrar = ttk.Button(self.main_frame, text="Registrar Cliente", command=self.registrar_cliente)
        self.btn_registrar.grid(row=4, column=0, columnspan=2, pady=5, sticky="nsew")
        self.btn_registrar.config(state="disabled")

        self.btn_limpar = ttk.Button(self.main_frame, text="Limpar Campos", command=self.limpar_campos)
        self.btn_limpar.grid(row=5, column=0, columnspan=2, pady=5, sticky="nsew")

        self.btn_consultar = ttk.Button(self.main_frame, text="Consultar Clientes", command=self.consultar_clientes, state="disabled")
        self.btn_consultar.grid(row=6, column=0, columnspan=2, pady=5, sticky="nsew")

    def limitar_entrada(self, var):
        if len(var.get()) > 50:
            var.set(var.get()[:50])

    def registrar_cliente(self):
        nome = self.var_nome.get().strip()
        email = self.var_email.get().strip()
        telefone = self.var_telefone.get().strip()
        cpf = self.var_cpf.get().strip()

        errors = self.validar_dados(nome, email, telefone, cpf)
        if errors:
            messagebox.showerror("Erro no Preenchimento", "\n".join(errors))
            return

        duplicidade_msg = self.checar_duplicidade(None, nome, email, telefone, cpf)
        if duplicidade_msg:
            messagebox.showerror("Erro no Cadastro", f"Já existe um cliente cadastrado com o mesmo {duplicidade_msg}")
            return

        self.clientes.append({"Nome": nome, "E-mail": email, "Telefone": telefone, "CPF": cpf})
        messagebox.showinfo("Registro de Cliente", "Cliente registrado com sucesso!")
        self.limpar_campos()

    def limpar_campos(self):
        self.entry_nome.delete(0, tk.END)
        self.entry_email.delete(0, tk.END)
        self.entry_telefone.delete(0, tk.END)
        self.entry_cpf.delete(0, tk.END)

    def validar_dados(self, nome, email, telefone, cpf):
        errors = []
        if not nome or ' ' not in nome:
            errors.append("Por favor, insira um nome e um sobrenome.")
        if not re.match(r"[^@]+@[^@]+\.[^@]+", email) or ' ' in email:
            errors.append("Por favor, insira um endereço de e-mail válido sem espaços.")
        if not telefone.isdigit() or len(telefone) != 11:
            errors.append("Por favor, insira um número de telefone válido com 11 dígitos.")
        if not self.validar_cpf(cpf):
            errors.append("Por favor, insira um CPF válido.")
        return errors

    def validar_cpf(self, cpf):
        cpf = ''.join(filter(str.isdigit, cpf))
        if (len(cpf) != 11) or (cpf == cpf[0] * 11):
            return False

        for i in range(9, 11):
            soma = sum((int(cpf[num]) * ((i + 1) - num) for num in range(0, i)))
            digito = ((soma * 10) % 11) % 10
            if int(cpf[i]) != digito:
                return False
        return True

    def consultar_clientes(self):
        if self.janela_consulta_atual is not None:
            self.janela_consulta_atual.destroy()

        self.consulta_window = tk.Toplevel(self.root)
        self.consulta_window.title("Clientes Registrados")
        self.janela_consulta_atual = self.consulta_window

        pesquisa_frame = ttk.Frame(self.consulta_window)
        pesquisa_frame.pack(fill="x", padx=10, pady=5)

        self.pesquisa_entry = ttk.Entry(pesquisa_frame)
        self.pesquisa_entry.pack(side=tk.LEFT, expand=True, fill="x", padx=(0, 5))
        btn_buscar = ttk.Button(pesquisa_frame, text="Buscar", command=self.filtrar_clientes)
        btn_buscar.pack(side=tk.LEFT)

        self.tree = ttk.Treeview(self.consulta_window, columns=("Nome", "E-mail", "Telefone", "CPF"), show="headings")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("E-mail", text="E-mail")
        self.tree.heading("Telefone", text="Telefone")
        self.tree.heading("CPF", text="CPF")

        for cliente in self.clientes:
            self.tree.insert("", tk.END, values=(cliente["Nome"], cliente["E-mail"], cliente["Telefone"], cliente["CPF"]))

        self.tree.pack(expand=True, fill="both")

        button_frame = ttk.Frame(self.consulta_window)
        button_frame.pack(fill="x", pady=5)

        btn_excluir = ttk.Button(button_frame, text="Excluir", command=lambda: self.excluir_cliente(self.tree))
        btn_excluir.pack(side=tk.LEFT, expand=True)

        btn_editar = ttk.Button(button_frame, text="Editar", command=self.editar_cliente)
        btn_editar.pack(side=tk.RIGHT, expand=True)

    def filtrar_clientes(self):
        busca_termo = self.pesquisa_entry.get().strip().lower()
        for item in self.tree.get_children():
            self.tree.delete(item)
        for cliente in self.clientes:
            if busca_termo in cliente["Nome"].lower() or \
               busca_termo in cliente["E-mail"].lower() or \
               busca_termo in cliente["Telefone"].lower() or \
               busca_termo in cliente["CPF"].lower():
                self.tree.insert("", tk.END, values=(cliente["Nome"], cliente["E-mail"], cliente["Telefone"], cliente["CPF"]))

    def excluir_cliente(self, tree):
        selecionado = tree.selection()
        if not selecionado:
            messagebox.showerror("Erro", "Selecione um cliente para excluir.")
            return
        confirmacao = messagebox.askyesno("Excluir Cliente", "Tem certeza que deseja excluir o cliente selecionado?")
        if confirmacao:
            for item in selecionado:
                cliente_selecionado = tree.item(item, "values")
                self.clientes = [cliente for cliente in self.clientes if cliente["CPF"] != cliente_selecionado[3]]
                tree.delete(item)
            messagebox.showinfo("Sucesso", "Cliente excluído com sucesso.")

    def editar_cliente(self):
        selecionado = self.tree.selection()
        if not selecionado:
            messagebox.showerror("Erro", "Selecione um cliente para editar.")
            return

        self.edit_window = tk.Toplevel(self.root)
        self.edit_window.title("Editar Cliente")

        cliente_selecionado = self.tree.item(selecionado[0], "values")
        self.index_cliente_editando = next((index for (index, d) in enumerate(self.clientes) if d["CPF"] == cliente_selecionado[3]), None)

        tk.Label(self.edit_window, text="Nome Completo:").grid(row=0, column=0, sticky="e")
        self.edit_var_nome = tk.StringVar(value=cliente_selecionado[0])
        self.edit_nome = tk.Entry(self.edit_window, width=40, textvariable=self.edit_var_nome)
        self.edit_nome.grid(row=0, column=1)
        self.edit_var_nome.trace("w", lambda *args: self.limitar_entrada(self.edit_var_nome))

        tk.Label(self.edit_window, text="E-mail:").grid(row=1, column=0, sticky="e")
        self.edit_var_email = tk.StringVar(value=cliente_selecionado[1])
        self.edit_email = tk.Entry(self.edit_window, width=40, textvariable=self.edit_var_email)
        self.edit_email.grid(row=1, column=1)
        self.edit_var_email.trace("w", lambda *args: self.limitar_entrada(self.edit_var_email))

        tk.Label(self.edit_window, text="Telefone:").grid(row=2, column=0, sticky="e")
        self.edit_var_telefone = tk.StringVar(value=cliente_selecionado[2])
        self.edit_telefone = tk.Entry(self.edit_window, width=40, textvariable=self.edit_var_telefone)
        self.edit_telefone.grid(row=2, column=1)
        self.edit_var_telefone.trace("w", lambda *args: self.limitar_entrada(self.edit_var_telefone))

        tk.Label(self.edit_window, text="CPF:").grid(row=3, column=0, sticky="e")
        self.edit_var_cpf = tk.StringVar(value=cliente_selecionado[3])
        self.edit_cpf = tk.Entry(self.edit_window, width=40, textvariable=self.edit_var_cpf)
        self.edit_cpf.grid(row=3, column=1)
        self.edit_var_cpf.trace("w", lambda *args: self.limitar_entrada(self.edit_var_cpf))

        btn_salvar = ttk.Button(self.edit_window, text="Salvar", command=self.salvar_edicao)
        btn_salvar.grid(row=4, column=0, columnspan=2, pady=5, sticky="nsew")

    def salvar_edicao(self):
        nome = self.edit_var_nome.get().strip()
        email = self.edit_var_email.get().strip()
        telefone = self.edit_var_telefone.get().strip()
        cpf = self.edit_var_cpf.get().strip()

        errors = self.validar_dados(nome, email, telefone, cpf)
        if errors:
            messagebox.showerror("Erro no Preenchimento", "\n".join(errors))
            return

        duplicidade_msg = self.checar_duplicidade(self.index_cliente_editando, nome, email, telefone, cpf)
        if duplicidade_msg:
            messagebox.showerror("Erro no Cadastro", f"Já existe um cliente cadastrado com o mesmo {duplicidade_msg}")
            return

        self.clientes[self.index_cliente_editando] = {"Nome": nome, "E-mail": email, "Telefone": telefone, "CPF": cpf}
        messagebox.showinfo("Sucesso", "Cliente editado com sucesso!")
        self.edit_window.destroy()
        self.consultar_clientes()

    def checar_duplicidade(self, index_editando, nome, email, telefone, cpf):
        for index, cliente in enumerate(self.clientes):
            if index != index_editando:
                if cliente["Nome"].lower() == nome.lower():
                    return "nome"
                if cliente["CPF"] == cpf:
                    return "CPF"
                if cliente["E-mail"].lower() == email.lower():
                    return "e-mail"
                if cliente["Telefone"] == telefone:
                    return "telefone"
        return ""

    def fechar_aplicativo(self):
        self.running = False  
        if self.thread_autosalvamento:
            self.thread_autosalvamento.cancel()  
        if self.clientes and not self.arquivo_salvo:
            opcao = messagebox.askquestion("Fechar Aplicativo", "Você perderá todos os clientes registrados. Deseja salvar antes de sair?")
            if opcao == 'yes':
                self.salvar_arquivo()
        self.root.destroy()

    def salvar_automaticamente(self):
        if self.running:  
            self.thread_autosalvamento = threading.Timer(300, self.salvar_automaticamente)
            self.thread_autosalvamento.start()  
            if self.arquivo_atual and self.clientes:
                try:
                    with open(self.arquivo_atual, "w") as f:
                        json.dump(self.clientes, f)
                    print("Dados salvos automaticamente.")
                except Exception as e:
                    print(f"Erro ao salvar automaticamente: {str(e)}")

def main():
    root = tk.Tk()
    app = RegistroClienteApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
